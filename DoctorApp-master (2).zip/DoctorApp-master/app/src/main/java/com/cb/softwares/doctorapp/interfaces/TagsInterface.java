package com.cb.softwares.doctorapp.interfaces;

public interface TagsInterface {

    void createTag();
}
