package com.cb.softwares.doctorapp.notification;

public class MyResponse {


public int success;

}
