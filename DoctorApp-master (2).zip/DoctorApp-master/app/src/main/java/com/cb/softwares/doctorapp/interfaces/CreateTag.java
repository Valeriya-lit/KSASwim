package com.cb.softwares.doctorapp.interfaces;

import com.cb.softwares.doctorapp.model.TagCreation;

public interface CreateTag {
    void createTag(TagCreation creation);
}
