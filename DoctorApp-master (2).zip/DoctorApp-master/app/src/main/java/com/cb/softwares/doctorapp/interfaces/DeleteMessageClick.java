package com.cb.softwares.doctorapp.interfaces;

public interface DeleteMessageClick {

     void select(int pos);
     void unSelect(int pos);
     void onSelectEnable(int pos);

}
