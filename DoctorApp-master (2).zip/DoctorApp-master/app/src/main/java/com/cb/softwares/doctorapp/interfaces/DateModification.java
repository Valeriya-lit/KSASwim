package com.cb.softwares.doctorapp.interfaces;

public interface DateModification {

    void modifyDate(int pos);

    void select(int pos);
    void unSelect(int pos);
    void enableSelection(int pos);
    void modifyTime(int  pos);

}
